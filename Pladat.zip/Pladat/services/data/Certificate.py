class Certificate(object):

    def __init__(self, certificate):

        self.certificate=certificate