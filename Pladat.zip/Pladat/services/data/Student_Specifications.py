class StudentSpecifications(object):

    def __init__(self, department, degree):

        self.department = department
        self.degree = degree