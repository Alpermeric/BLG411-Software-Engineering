'''
@Author Alper Meriç
'''
class Experience(object):

    def __init__(self, company_name,title,start_date,finish_date,descriptions):

        self.company_name=company_name
        self.title=title
        self.start_date =start_date
        self.finish_date=finish_date
        self.descriptions=descriptions