'''
@Author Alper Meriç
'''
class PersonalContactInfo(object):

    def __init__(self, first_name,last_name,mobile,email,location):

        self.first_name=first_name
        self.last_name=last_name
        self.mobile =mobile
        self.email=email
        self.location=location