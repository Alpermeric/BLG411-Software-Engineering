class Certificate_Placement(object):

    def __init__(self, certificate_placement):

        self.certificate_placement = certificate_placement