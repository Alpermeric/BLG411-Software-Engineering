'''
@Author Alper Meriç
'''
class Skills(object):

    def __init__(self, Skills):
        self.Skills=Skills