'''
@Author Gamze Tuncay
'''
class Placement(object):

    def __init__(self, title, category, email, location, salary, description):

        self.title = title
        self.category = category
        self.email = email
        self.location = location
        self.salary = salary
        self.description = description