class Skills_Placement(object):

    def __init__(self, skills_placement):
        
        self.skills_placement = skills_placement