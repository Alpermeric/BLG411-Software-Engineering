class Benefits(object):

    def __init__(self, benefits):
        self.benefits = benefits