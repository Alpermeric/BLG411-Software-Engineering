'''
@Author Alper Meriç
'''
class EducationalInfo(object):

    def __init__(self, university_name,department_name,university_start_year,university_graduate_year,actual_gpa):

        self.university_name=university_name
        self.department_name=department_name
        self.university_start_year =university_start_year
        self.university_graduate_year=university_graduate_year
        self.actual_gpa=actual_gpa