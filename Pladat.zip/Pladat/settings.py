DEBUG = True
PORT = 8080
SECRET_KEY = "secret"
WTF_CSRF_ENABLED = True
baseUrl = "https://hp8xm3yzr0.execute-api.us-east-2.amazonaws.com/prod/"