'''
@Author Alper Meriç
'''
from flask.views import View
from flask import render_template, request, redirect, url_for, session
from services.API.api import searchJobsByCategory, searchByLocation, searchByKeywords, sortBydate, matchedPlacements
import json
class HomepageView(View):
    def __init__(self):
        s_id = session['studentId']
        jobs = matchedPlacements(s_id)
        print('jobsinit', jobs)
        if jobs == 500 or type(jobs)==str:
            jobs = []
        self.jobs = jobs

    def get_template_name(self):
        return render_template("./homepage.html",  context = self.jobs)
    
    def dispatch_request(self,**kwargs):

        if request.method == "POST" and 'search' in request.form:
            if request.form["search"] == "search":
                search = request.form.get('search-button')
                response = searchByKeywords(search)
                self.jobs = response
        
        if request.method == "POST" and 'date' in request.form:
            if request.form["date"] == "date":
                response = sortBydate()
                self.jobs = response

        if kwargs:
            print(kwargs)
            if kwargs.get('category'):
                category = kwargs.get('category')
                self.jobs = searchJobsByCategory(category)
                print("catego",self.jobs)

            if kwargs.get('location'):
                location = kwargs.get('location')
                self.jobs = searchByLocation(location)
                print("location",self.jobs)

            if kwargs.get('key'):
                location = kwargs.get('key')
                self.jobs = searchByKeywords(location)
                print("key",self.jobs)

        print('jobs=', self.jobs)
        return render_template("./homepage.html", context = self.jobs)       