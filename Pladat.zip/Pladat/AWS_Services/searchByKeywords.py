import json
import boto3
from boto3.dynamodb.conditions import Attr


def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb',region_name = 'us-east-2')
    keyword = event['keywords']
    table = dynamodb.Table('Jobs')
    respone = table.scan()
    if respone['Count']==0:
        return 403
    data = respone ['Items']
    
    x = []
    y = []
    index = 0 
    
    for item in data:
        for key, value in item.items():
            if value == keyword:
                if item not in x:
                    x.append(item)
                    table = dynamodb.Table('Skills_jobs')
                    respone = table.scan(FilterExpression=Attr('Jobs_ID').eq(item['ID']))
                    y.append  ( {'Skills':respone [ 'Items']})
                    table2 = dynamodb.Table('Benefits')
                    respone = table2.scan(FilterExpression=Attr('Jobs_ID').eq(item['ID']))
                    y.append ( {'Benefits':respone [ 'Items']})
                    table3 = dynamodb.Table('Certificates_job')
                    respone = table3.scan(FilterExpression=Attr('Jobs_ID').eq(item['ID']))
                    y.append ( {'Certificates':respone [ 'Items']})
                    index = index + 1

    if len(x) == 0 :
        return 403
    for i in range(index*3):
        x[int(i/3)].update(y[i])
    return x
