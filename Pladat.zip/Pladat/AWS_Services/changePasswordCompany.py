import json
import boto3
from boto3.dynamodb.conditions import Key,Attr


def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb',region_name = 'us-east-2')
    table = dynamodb.Table('Company')
    respone = table.scan(FilterExpression=Attr('ID').eq(int(event['ID'])) & Attr('password').eq(event['oldPassword']))
    print(respone)
    if respone['Count']==0:
        return 403
    response = table.update_item(
        Key={
            'ID': int(event['ID'])
        },
        UpdateExpression="set password = :password ",
        ExpressionAttributeValues={
            ':password': event['newPassword'],
        },
        ReturnValues="UPDATED_NEW"
    )
    return True 
    
