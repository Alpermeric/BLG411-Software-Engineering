import json
import boto3
from boto3.dynamodb.conditions import Attr


def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb',region_name = 'us-east-2')
    table = dynamodb.Table('Company')
    respone = table.scan(FilterExpression=Attr('email').eq(event['Email']) & Attr('password').eq(event['Password']))
    print(respone)
    if respone['Count']==0:
        return 403
    data = respone ['Items'][0]
    return data['ID']
    
