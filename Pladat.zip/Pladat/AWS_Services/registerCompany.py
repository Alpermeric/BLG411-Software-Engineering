import json
import boto3
from boto3.dynamodb.conditions import Attr


def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb',region_name = 'us-east-2')
    table = dynamodb.Table('Company')
    respone = table.scan(FilterExpression=Attr('email').eq(event['Email']))
    print(respone)
    if respone['Count']!=0:
        return 403
    ID = respone['ScannedCount']
    respone = table.scan()
    data=respone['Items']
    x = []
    for item in data:
        x.append(item['ID'])
    ID = max(x)
    response = table.put_item(
    Item={
        'ID': ID + 1,
        'email': event['Email'],
        'username': event['Username'],
        'password': event['Password'],
    }
)
    return ID + 1 
    
