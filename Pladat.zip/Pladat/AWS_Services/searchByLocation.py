import json
import boto3
from boto3.dynamodb.conditions import Attr


def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb',region_name = 'us-east-2')
    table = dynamodb.Table('Jobs')
    respone = table.scan(FilterExpression=Attr('location').eq(event['location']))
    if respone['Count']==0:
        return 403
    data = respone ['Items']
    table = dynamodb.Table('Skills_jobs')
    x = []
    index = 0 
    for item in data:
        respone = table.scan(FilterExpression=Attr('Jobs_ID').eq(item['ID']))
        print(item['ID'])
        x.append({'items':respone ['Items']})
        data[index].update  ( {'Skills':respone [ 'Items']})
        index = index + 1 
    table = dynamodb.Table('Benefits')
    index = 0 
    for item in data:
        respone = table.scan(FilterExpression=Attr('Jobs_ID').eq(item['ID']))
        data[index].update  ( {'Benefits':respone [ 'Items']})
        index = index + 1     
    table = dynamodb.Table('Certificates_job')
    index = 0 
    for item in data:
        respone = table.scan(FilterExpression=Attr('Jobs_ID').eq(item['ID']))
        data[index].update  ( {'Certificates':respone [ 'Items']})
        index = index + 1         
    return data
    
